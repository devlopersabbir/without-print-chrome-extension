/**
 * Name: Print Shortcut Google Chrome Extension
 * Version: 0.0.1
 * Manifest_version: 3
 * Supported: Google Chrome | null
 * Language: JavaScript && HTML && JSON
 * Author: Sabbir Hossain Shuvo
 * Author_Email: devlopersabbir@gmail.com
 * Author_username: @devlopersabbir
 * Github_repo: https://github.com/devlopersabbir/without-print-chrome-extension
 */
